export declare class Query {
    static myEntityCollection: any;
    constructor();
    static ArcgisQuery(czmObject: any, index: any, params: any, callback: any): void;
    static GeoserverQuery(czmObject: any, params: any): void;
    static clearHighLight(): void;
}
//# sourceMappingURL=query.d.ts.map