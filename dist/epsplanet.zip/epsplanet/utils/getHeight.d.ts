declare function getPositionsHeightFromTileset(earth: any, positions: any, resultCallback: any): void;
declare function getPositionsHeightFromTerrain(earth: any, positions: any, resultCallback: any): void;
export { getPositionsHeightFromTerrain, getPositionsHeightFromTileset };
//# sourceMappingURL=getHeight.d.ts.map