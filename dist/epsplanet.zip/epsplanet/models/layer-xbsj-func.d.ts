import { IXbsjCzmObject } from './layer-xbsj';
import { ILayerFolder } from './layer-config';
export declare function newXbsjFolderNode(title: string): ILayerFolder;
export declare function newXbsjLayerNode(type: string, title: string, url: string): IXbsjCzmObject;
//# sourceMappingURL=layer-xbsj-func.d.ts.map